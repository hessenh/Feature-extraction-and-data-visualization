/**
 * 
 */
package weka.estimators;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author marco
 *
 */
public class TestMultivariateNormalHMMEstimator {

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#getOutputDimension()}.
	 */
	@Test
	public void testGetOutputDimension() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#setTied(boolean)}.
	 */
	@Test
	public void testSetTied() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#setCovarianceType(weka.estimators.MultivariateNormalEstimator.CovarianceType)}.
	 */
	@Test
	public void testSetCovarianceType() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#MultivariateNormalHMMEstimator(int, boolean)}.
	 */
	@Test
	public void testMultivariateNormalHMMEstimatorIntBoolean() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#MultivariateNormalHMMEstimator(weka.estimators.MultivariateNormalHMMEstimator)}.
	 */
	@Test
	public void testMultivariateNormalHMMEstimatorMultivariateNormalHMMEstimator() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#copyOutputParameters(weka.estimators.MultivariateNormalHMMEstimator)}.
	 */
	@Test
	public void testCopyOutputParameters() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#setState0Probabilities(double[])}.
	 */
	@Test
	public void testSetState0Probabilities() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#setStateProbabilities(double[][])}.
	 */
	@Test
	public void testSetStateProbabilities() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#setOutputMeans(weka.core.matrix.DoubleVector[])}.
	 */
	@Test
	public void testSetOutputMeans() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#setOutputMean(int, weka.core.matrix.DoubleVector)}.
	 */
	@Test
	public void testSetOutputMean() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#setOutputVariances(weka.core.matrix.Matrix[])}.
	 */
	@Test
	public void testSetOutputVariances() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#setOutputVariance(int, weka.core.matrix.Matrix)}.
	 */
	@Test
	public void testSetOutputVariance() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#Sample(weka.core.Instances, int, java.util.Random)}.
	 */
	@Test
	public void testSample() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#Sample0(weka.core.Instances, java.util.Random)}.
	 */
	@Test
	public void testSample0() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#addValue(double, double, weka.core.matrix.DoubleVector, double)}.
	 */
	@Test
	public void testAddValueDoubleDoubleDoubleVectorDouble() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#addValue0(double, weka.core.matrix.DoubleVector, double)}.
	 */
	@Test
	public void testAddValue0DoubleDoubleVectorDouble() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#getProbability(double, double, weka.core.matrix.DoubleVector)}.
	 */
	@Test
	public void testGetProbabilityDoubleDoubleDoubleVector() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#getProbability0(double, weka.core.matrix.DoubleVector)}.
	 */
	@Test
	public void testGetProbability0DoubleDoubleVector() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#addValue(double, double, double, double)}.
	 */
	@Test
	public void testAddValueDoubleDoubleDoubleDouble() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#addValue0(double, double, double)}.
	 */
	@Test
	public void testAddValue0DoubleDoubleDouble() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#getProbability(double, double, double)}.
	 */
	@Test
	public void testGetProbabilityDoubleDoubleDouble() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link weka.estimators.MultivariateNormalHMMEstimator#getProbability0(double, double)}.
	 */
	@Test
	public void testGetProbability0DoubleDouble() {
		fail("Not yet implemented");
	}

}
